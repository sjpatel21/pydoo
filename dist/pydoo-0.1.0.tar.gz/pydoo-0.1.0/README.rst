pydoo: sdk for odoo xmlrpc api
==============================


[![build status](https://gitlab.com/gitlab-org/gitlab-ce/badges/master/build.svg)](https://gitlab.com/julivico/pydoo/commits/master)