# -*- coding: utf-8 -*-

from .odoo_xmlrpc import OdooXmlRpc
from . import operator

Operator = operator
