pydoo: sdk for odoo xmlrpc api
==============================

travis test
-----------

.. image:: https://travis-ci.org/julivico/pydoo.svg?branch=master
    :target: https://travis-ci.org/julivico/pydoo
