INT = int
BOOLEAN = bool
STRING = str
