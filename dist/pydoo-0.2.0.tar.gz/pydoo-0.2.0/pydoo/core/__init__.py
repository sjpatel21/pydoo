# -*- coding: utf-8 -*-

from .odoo_xmlrpc import Connection
from . import operator

Operator = operator
