# -*- coding: utf-8 -*-

from .connector import Odoo
from .models.model import Model
